import { SHAPES, calculateRatio, validateMeasurement, formatRatio, describeProportion, lengthDifferencePercent } from './calculator.js';

const $ = (id) => document.getElementById(id);
const fields = {
  shape: $('shape'), length: $('length'), width: $('width'),
  compareShape: $('compare-shape'), compareLength: $('compare-length'), compareWidth: $('compare-width')
};
const graphics = {
  oval: 'M0,-1 C.61,-1 1,-.53 1,0 C1,.53 .61,1 0,1 C-.61,1 -1,.53 -1,0 C-1,-.53 -.61,-1 0,-1Z',
  round: 'M0,-1 C.552,-1 1,-.552 1,0 C1,.552 .552,1 0,1 C-.552,1 -1,.552 -1,0 C-1,-.552 -.552,-1 0,-1Z',
  pear: 'M0,-1 C.42,-.72 1,-.06 1,.42 C1,.8 .59,1 0,1 C-.59,1 -1,.8 -1,.42 C-1,-.06 -.42,-.72 0,-1Z',
  marquise: 'M0,-1 C.25,-.64 1,-.27 1,0 C1,.27 .25,.64 0,1 C-.25,.64 -1,.27 -1,0 C-1,-.27 -.25,-.64 0,-1Z',
  emerald: 'M-.69,-1 H.69 L1,-.68 V.68 L.69,1 H-.69 L-1,.68 V-.68 Z',
  radiant: 'M-.81,-1 H.81 L1,-.78 V.78 L.81,1 H-.81 L-1,.78 V-.78 Z',
  cushion: 'M0,-1 C.75,-1 1,-.74 1,0 C1,.74 .75,1 0,1 C-.75,1 -1,.74 -1,0 C-1,-.74 -.75,-1 0,-1Z',
  princess: 'M-1,-1 H1 V1 H-1 Z',
  asscher: 'M-.7,-1 H.7 L1,-.7 V.7 L.7,1 H-.7 L-1,.7 V-.7 Z'
};
const facetPath = {
  oval: 'M0,-1 L-.52,-.3 L0,1 L.52,-.3 Z M-1,0 L0,-.34 L1,0 L0,.38Z M0,-1 V1',
  round: 'M0,-1 L-.64,-.64 L-1,0 L-.64,.64 L0,1 L.64,.64 L1,0 L.64,-.64Z M-1,0 H1 M0,-1 V1',
  pear: 'M0,-1 L-.42,.0 L0,1 L.42,0Z M-.95,.35 H.95 M0,-1 V1',
  marquise: 'M0,-1 L-.55,0 L0,1 L.55,0Z M-1,0 H1 M0,-1 V1',
  emerald: 'M-.69,-1 L-.55,-.72 H.55 L.69,-1 M-1,-.68 L-.64,-.55 V.55 L-1,.68 M1,-.68 L.64,-.55 V.55 L1,.68 M-.69,1 L-.55,.72 H.55 L.69,1 M-.55,-.72 V.72 M.55,-.72 V.72',
  radiant: 'M-.81,-1 L-.57,-.6 H.57 L.81,-1 M-1,-.78 L-.6,-.48 V.48 L-1,.78 M1,-.78 L.6,-.48 V.48 L1,.78 M-.81,1 L-.57,.6 H.57 L.81,1 M0,-.6 V.6 M-.6,0 H.6',
  cushion: 'M0,-1 L-.55,-.55 L-.7,0 L-.55,.55 L0,1 L.55,.55 L.7,0 L.55,-.55Z M-1,0 H1 M0,-1 V1',
  princess: 'M-1,-1 L0,0 L1,-1 M-1,1 L0,0 L1,1 M0,-1 V1 M-1,0 H1',
  asscher: 'M-.7,-1 L-.55,-.7 H.55 L.7,-1 M-1,-.7 L-.7,-.55 V.55 L-1,.7 M1,-.7 L.7,-.55 V.55 L1,.7 M-.7,1 L-.55,.7 H.55 L.7,1 M-.55,-.7 V.7 M.55,-.7 V.7'
};
let comparing = false;
let toastTimer;

function getStone(shape, length, width) {
  const lengthError = validateMeasurement(length.value);
  const widthError = validateMeasurement(width.value);
  let error = lengthError || widthError;
  if (!error && Number(length.value) < Number(width.value)) error = 'Length is smaller than width. Check which measurement is the longer face-up dimension.';
  for (const input of [length, width]) input.setAttribute('aria-invalid', error ? 'true' : 'false');
  if (error) return { error };
  return { shape: shape.value, length: Number(length.value), width: Number(width.value), ratio: calculateRatio(length.value, width.value) };
}

function setMessage(id, message) { const el = $(id); el.textContent = message || ''; el.hidden = !message; }
function setVisible(id, visible) { $(id).hidden = !visible; }

function drawShape(stone) {
  const graphic = $('stone-graphic');
  if (!stone) { graphic.setAttribute('visibility', 'hidden'); return; }
  graphic.removeAttribute('visibility');
  // Max 210px wide by 235px high, so the drawn aspect ratio is always exact.
  const factor = Math.min(110, 117.5 / stone.ratio);
  const sx = factor, sy = factor * stone.ratio;
  graphic.setAttribute('transform', `translate(220 150) scale(${sx.toFixed(3)} ${sy.toFixed(3)})`);
  $('stone-outline').setAttribute('d', graphics[stone.shape]);
  $('stone-facets').setAttribute('d', facetPath[stone.shape]);
  $('length-dimension').textContent = `${stone.length.toFixed(2)} mm`;
  $('width-dimension').textContent = `${stone.width.toFixed(2)} mm`;
  $('shape-svg').setAttribute('aria-label', `Schematic ${SHAPES[stone.shape]} outline, length ${stone.length.toFixed(2)} millimetres, width ${stone.width.toFixed(2)} millimetres`);
}

function displayResult(stone) {
  if (stone.error) {
    setMessage('measurement-error', stone.error);
    $('ratio-result').innerHTML = '—<span>:1</span>';
    $('result-shape').textContent = 'Enter valid measurements';
    $('result-explanation').textContent = 'Both measurements must be positive, and length should be the longer dimension.';
    drawShape(null);
    $('copy-result').disabled = true;
    $('share-result').disabled = true;
    return;
  }
  setMessage('measurement-error', '');
  $('ratio-result').innerHTML = `${stone.ratio.toFixed(2)}<span>:1</span>`;
  $('result-shape').textContent = `${SHAPES[stone.shape]} · ${describeProportion(stone.ratio, stone.shape)}`;
  const p = lengthDifferencePercent(stone.ratio);
  $('result-explanation').textContent = Math.abs(p) < 0.05
    ? 'Length and width are approximately equal. This describes the outline, not cut quality.'
    : `The outline is approximately ${Math.abs(p).toFixed(1)}% ${p >= 0 ? 'longer than it is wide' : 'wider than it is long'}. This describes the silhouette, not cut quality.`;
  $('copy-result').disabled = false;
  $('share-result').disabled = false;
  drawShape(stone);
}

function renderComparison(a, b) {
  setVisible('comparison-result', comparing);
  if (!comparing) return;
  if (b.error || a.error) {
    setMessage('compare-error', b.error ? b.error : 'Please correct Diamond A first.');
    $('comparison-result').querySelectorAll('.bar-fill').forEach((el) => el.style.width = '0%');
    $('comparison-delta').textContent = 'Enter valid measurements';
    $('stone-a-ratio').textContent = a.error ? '—' : formatRatio(a.ratio);
    $('stone-b-ratio').textContent = b.error ? '—' : formatRatio(b.ratio);
    return;
  }
  setMessage('compare-error', '');
  $('stone-a-name').textContent = `A · ${SHAPES[a.shape]}`;
  $('stone-b-name').textContent = `B · ${SHAPES[b.shape]}`;
  $('stone-a-ratio').textContent = formatRatio(a.ratio);
  $('stone-b-ratio').textContent = formatRatio(b.ratio);
  $('comparison-delta').textContent = `Ratio difference: ${Math.abs(a.ratio - b.ratio).toFixed(2)}`;
  const max = Math.max(a.ratio, b.ratio, 1);
  $('stone-a-bar').style.width = `${Math.min(100, a.ratio / max * 100).toFixed(2)}%`;
  $('stone-b-bar').style.width = `${Math.min(100, b.ratio / max * 100).toFixed(2)}%`;
}

function update() {
  const a = getStone(fields.shape, fields.length, fields.width);
  const b = comparing ? getStone(fields.compareShape, fields.compareLength, fields.compareWidth) : null;
  displayResult(a);
  renderComparison(a, b);
}

function getState() {
  return {
    shape: fields.shape.value, length: fields.length.value, width: fields.width.value,
    ...(comparing ? { compare: '1', shapeB: fields.compareShape.value, lengthB: fields.compareLength.value, widthB: fields.compareWidth.value } : {})
  };
}

function toast(message) {
  const el = $('toast');
  clearTimeout(toastTimer);
  el.textContent = message;
  el.classList.add('toast-show');
  toastTimer = setTimeout(() => el.classList.remove('toast-show'), 3000);
}

async function copyText(text, success) {
  try {
    if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(text);
    else {
      const input = document.createElement('textarea');
      input.value = text; input.setAttribute('readonly', ''); input.style.position = 'absolute'; input.style.left = '-9999px';
      document.body.appendChild(input); input.select();
      if (!document.execCommand('copy')) throw new Error('Clipboard unavailable');
      input.remove();
    }
    toast(success);
  } catch {
    toast('Clipboard access was blocked. Please copy manually from the result.');
  }
}

function toggleCompare(value) {
  comparing = value;
  $('compare-toggle').setAttribute('aria-expanded', String(comparing));
  $('compare-fields').hidden = !comparing;
  $('compare-toggle').classList.toggle('compare-open', comparing);
  update();
}

$('ratio-form').addEventListener('submit', (event) => event.preventDefault());
Object.values(fields).forEach((field) => {
  field.addEventListener('input', update);
  field.addEventListener('change', update);
});
$('compare-toggle').addEventListener('click', () => toggleCompare(!comparing));
$('reset-button').addEventListener('click', () => {
  fields.shape.value = 'oval'; fields.length.value = '9.00'; fields.width.value = '6.20';
  fields.compareShape.value = 'pear'; fields.compareLength.value = '9.80'; fields.compareWidth.value = '6.20';
  toggleCompare(false);
  toast('Calculator reset to example values.');
});
$('copy-result').addEventListener('click', () => {
  const a = getStone(fields.shape, fields.length, fields.width);
  const b = comparing ? getStone(fields.compareShape, fields.compareLength, fields.compareWidth) : null;
  if (a.error || b?.error) return;
  const summary = `Diamond A · ${SHAPES[a.shape]} | ${a.length.toFixed(2)} × ${a.width.toFixed(2)} mm | Ratio ${formatRatio(a.ratio)}` + (b ? `\nDiamond B · ${SHAPES[b.shape]} | ${b.length.toFixed(2)} × ${b.width.toFixed(2)} mm | Ratio ${formatRatio(b.ratio)}` : '') + '\nDiamond Shape Ratio Calculator — Laxmi Jewellers Dubai';
  copyText(summary, 'Result copied to clipboard.');
});
$('share-result').addEventListener('click', () => {
  const a = getStone(fields.shape, fields.length, fields.width);
  const b = comparing ? getStone(fields.compareShape, fields.compareLength, fields.compareWidth) : null;
  if (a.error || b?.error) return;
  const url = new URL(window.location.href);
  url.search = new URLSearchParams(getState()).toString();
  url.hash = 'calculator';
  copyText(url.toString(), 'Share link copied. Measurements are included in the link.');
});
for (const button of document.querySelectorAll('[data-preset]')) {
  button.addEventListener('click', () => {
    fields.shape.value = button.dataset.preset;
    fields.length.value = button.dataset.length;
    fields.width.value = button.dataset.width;
    toggleCompare(false);
    $('calculator').scrollIntoView({ behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth', block: 'start' });
  });
}

function loadStateFromUrl() {
  const query = new URLSearchParams(window.location.search);
  const shape = query.get('shape');
  if (shape && Object.hasOwn(SHAPES, shape)) fields.shape.value = shape;
  const readValue = (key, field) => { const raw = query.get(key); if (raw !== null && raw.length <= 16) field.value = raw; };
  readValue('length', fields.length);
  readValue('width', fields.width);
  if (query.get('compare') === '1') {
    const shapeB = query.get('shapeB');
    if (shapeB && Object.hasOwn(SHAPES, shapeB)) fields.compareShape.value = shapeB;
    readValue('lengthB', fields.compareLength);
    readValue('widthB', fields.compareWidth);
    toggleCompare(true);
  }
}
$('footer-year').textContent = new Date().getFullYear();
loadStateFromUrl();
update();
