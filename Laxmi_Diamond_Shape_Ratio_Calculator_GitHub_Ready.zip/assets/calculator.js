/** Pure, dependency-free diamond proportion calculations. */
export const SHAPES = Object.freeze({
  oval: 'Oval', pear: 'Pear', marquise: 'Marquise', emerald: 'Emerald',
  radiant: 'Radiant', cushion: 'Cushion', asscher: 'Asscher',
  princess: 'Princess', round: 'Round'
});

/**
 * Given positive, finite measurements in the same unit, return length / width.
 * Do not swap the values silently: the form should make the inputs explicit.
 */
export function calculateRatio(length, width) {
  const l = Number(length);
  const w = Number(width);
  if (!Number.isFinite(l) || !Number.isFinite(w) || l <= 0 || w <= 0) {
    throw new RangeError('Length and width must be positive finite numbers.');
  }
  return l / w;
}

export function validateMeasurement(value) {
  if (String(value ?? '').trim() === '') return 'Please enter both measurements.';
  const n = Number(value);
  if (!Number.isFinite(n) || n <= 0) return 'Measurements must be greater than zero.';
  if (n > 1000) return 'Please enter measurements of 1,000 mm or less.';
  return null;
}

export function formatRatio(ratio) {
  if (!Number.isFinite(ratio) || ratio <= 0) throw new RangeError('Invalid ratio.');
  return `${ratio.toFixed(2)}:1`;
}

/** Neutral, descriptive language; never a grade or purchase recommendation. */
export function describeProportion(ratio, shape) {
  if (!Number.isFinite(ratio) || ratio <= 0) return 'Unknown proportion';
  if (ratio < 0.94) return 'Wider than long';
  if (ratio <= 1.06) return shape === 'round' ? 'Nearly circular' : 'Nearly equal dimensions';
  if (ratio < 1.25) return 'Slightly elongated';
  if (ratio < 1.5) return 'Moderately elongated';
  if (ratio < 1.8) return 'Distinctly elongated';
  return 'Strongly elongated';
}

export function lengthDifferencePercent(ratio) {
  if (!Number.isFinite(ratio) || ratio <= 0) throw new RangeError('Invalid ratio.');
  return (ratio - 1) * 100;
}
