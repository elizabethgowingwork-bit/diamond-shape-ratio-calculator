import test from 'node:test';
import assert from 'node:assert/strict';
import {SHAPES, calculateRatio, validateMeasurement, formatRatio, describeProportion, lengthDifferencePercent} from '../assets/calculator.js';

test('9/6 is 1.50:1', () => {
  assert.equal(calculateRatio(9, 6), 1.5);
  assert.equal(formatRatio(calculateRatio(9, 6)), '1.50:1');
});
test('9/6.2 is 1.45:1 with neutral description', () => {
  const r = calculateRatio('9.00', '6.20');
  assert.equal(formatRatio(r), '1.45:1');
  assert.equal(describeProportion(r, 'oval'), 'Moderately elongated');
  assert.ok(Math.abs(lengthDifferencePercent(r) - 45.16129) < 0.001);
});
test('near-square diamond works', () => {
  assert.equal(formatRatio(calculateRatio(6, 6)), '1.00:1');
  assert.equal(describeProportion(1, 'princess'), 'Nearly equal dimensions');
  assert.equal(describeProportion(1, 'round'), 'Nearly circular');
});
test('invalid values are rejected', () => {
  for (const v of [0, -1, Infinity, NaN]) assert.throws(() => calculateRatio(8, v), RangeError);
  assert.ok(validateMeasurement(''));
  assert.ok(validateMeasurement(-3));
  assert.ok(validateMeasurement('abc'));
  assert.ok(validateMeasurement('1001'));
  assert.equal(validateMeasurement('2.25'), null);
});
test('all nine shapes are exposed', () => assert.equal(Object.keys(SHAPES).length, 9));
test('ratio is not silently inverted', () => assert.equal(calculateRatio(5, 10), .5));
